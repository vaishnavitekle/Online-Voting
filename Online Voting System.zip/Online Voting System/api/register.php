<?php
 session_start();
   include("connect.php");
   
//if(isset($name)||isset($mobile)||isset($password)||isset($cpassword)||isset($addresss)||isset($role))
  // {
  $name= $_POST['name'];                   
  $mobile= $_SESSION['number'];
  $password= $_POST['password'];
  $cpassword= $_POST['cpassword'];
  $address= $_POST['address'];
  $image=$_FILES['image']['name'];
  $tmp_name=$_FILES['image']['tmp_name'];
  //$size=$_FILES['image']['size'];
  $role=$_POST['role'];
  $sql="insert into user(name,mobile,password,address,photo,role,status,votes) values('$name','$mobile','$password','$address','$image','$role',0,0)";
  $exitSql="select * from user where mobile='$mobile'";
  $result=mysqli_query($connect,$exitSql);
  $numExit=mysqli_num_rows($result);
  if($numExit>0){
    echo '
    <script>
    alert("✨Phone Number Already Exists✨");
    window.location="../register1.php";
    </script>
    ';
  }
  else{
  if($password==$cpassword){
    move_uploaded_file($tmp_name,"../uploads/".$image); //C:\xampp\htdocs\img\module_table_bottom.png
    $insert=mysqli_query($connect,$sql);
    if($insert){
        echo '
        <script>
        alert("✨registration successful ✔✨");
        window.location="../index.html";
        </script>
        '; 
        }
         else{
        echo '
        <script>
        alert("✨some error occure 🙄✨ ");
        window.location="../register1.php";
        </script>
        '; 
            }
         }
  else{
      echo '
      <script>
      alert("✨password & conform password do not match! 😒✨");
      window.location="../register1.php";
      </script>
      ';
  }
}
?>
